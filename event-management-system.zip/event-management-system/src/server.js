const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const connectDB = require("./config/db");
const errorHandler = require("./middleware/errorHandler");

// 加载环境变量
dotenv.config();

// 连接数据库
connectDB();

// 初始化Express
const app = express();

// 中间件
app.use(cors());
app.use(express.json());

// 记录请求日志
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// 路由
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/events", require("./routes/eventRoutes"));
app.use("/api/tickets", require("./routes/ticketRoutes"));
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/events", require("./routes/eventRoutes"));
app.use("/api/tickets", require("./routes/ticketRoutes"));
app.use("/api/reports", require("./routes/reportRoutes"));

// Basic routing
app.get("/", (req, res) => {
  res.send("The event management system API is running....");
});

// Error handling middleware
app.use(errorHandler);

const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

// helmet
app.use(helmet());

// Limit request frequency
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 mins
  max: 100, // Each IP has a maximum of 100 requests
});

app.use("/api/", limiter);

// setting port
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`The server is running on port ${PORT}`));

const swaggerUi = require("swagger-ui-express");
const swaggerDocs = require("./config/swagger");

// Swagger API document
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs));

// Handling Uncaught Exceptions
process.on("unhandledRejection", (err, promise) => {
  console.log(`Error: ${err.message}`);
  // Shut down the server and exit the process
  // server.close(() => process.exit(1));
});
