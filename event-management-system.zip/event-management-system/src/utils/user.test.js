const mongoose = require("mongoose");
const User = require("../../src/models/User");
const bcrypt = require("bcryptjs");

// Testing with an in-memory database
beforeAll(async () => {
  await mongoose.connect("mongodb://localhost:27017/test-db", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
});

describe("User Model Test", () => {
  it("should hash the password before saving", async () => {
    const userData = {
      name: "Test User",
      email: "test@example.com",
      password: "password123",
      role: "user",
    };

    const user = new User(userData);
    await user.save();

    // The password should have been encrypted
    expect(user.password).not.toBe(userData.password);

    // Verify password match
    const isMatch = await bcrypt.compare(userData.password, user.password);
    expect(isMatch).toBe(true);
  });

  it("should not rehash the password if not modified", async () => {
    // create user
    const user = new User({
      name: "Another User",
      email: "another@example.com",
      password: "password123",
      role: "user",
    });
    await user.save();

    const originalPassword = user.password;

    // update username
    user.name = "Updated Name";
    await user.save();

    expect(user.password).toBe(originalPassword);
  });
});
