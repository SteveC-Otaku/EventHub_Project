const mongoose = require("mongoose");
const dotenv = require("dotenv");
const User = require("../models/User");
const Event = require("../models/Event");
const Ticket = require("../models/Ticket");
const bcrypt = require("bcryptjs");

// Load environment variables
dotenv.config();

// Connect to the database
mongoose.connect(process.env.MONGODB_URI);

// Random data generation function
const getRandomElement = (array) =>
  array[Math.floor(Math.random() * array.length)];
const getRandomPrice = (min, max) =>
  Math.floor(Math.random() * (max - min + 1) + min);
const getRandomDate = (start, end) =>
  new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));

// Clear the database
const clearDatabase = async () => {
  await User.deleteMany({});
  await Event.deleteMany({});
  await Ticket.deleteMany({});
  console.log("The database has been cleared");
};

// Create user
const createUsers = async () => {
  const users = [];
  const roles = ["user", "organizer", "admin"];

  // Create an administrator user
  const adminUser = new User({
    name: "Admin User",
    email: "admin@example.com",
    password: await bcrypt.hash("admin123", 10),
    role: "admin",
  });
  await adminUser.save();
  users.push(adminUser);

  // Create 9 organizers
  for (let i = 0; i < 9; i++) {
    const organizer = new User({
      name: `Organizer ${i + 1}`,
      email: `organizer${i + 1}@example.com`,
      password: await bcrypt.hash("password123", 10),
      role: "organizer",
    });
    await organizer.save();
    users.push(organizer);
  }

  // Create 40 regular users
  for (let i = 0; i < 40; i++) {
    const user = new User({
      name: `User ${i + 1}`,
      email: `user${i + 1}@example.com`,
      password: await bcrypt.hash("password123", 10),
      role: "user",
    });
    await user.save();
    users.push(user);
  }

  console.log(`Create ${users.length} users`);
  return users;
};

// constructive activity
const createEvents = async (organizers) => {
  const events = [];
  const categories = ["conference", "music", "networking"];
  const locations = ["Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide"];
  const titles = [
    "Tech Summit",
    "Web Dev Conference",
    "Startup Meetup",
    "Classical Concert",
    "Rock Festival",
    "Jazz Night",
    "Business Networking",
    "Industry Meetup",
    "Professional Mixer",
  ];

  for (let i = 0; i < 30; i++) {
    const category = getRandomElement(categories);
    const startDate = getRandomDate(new Date(), new Date(2026, 0, 1));
    const endDate = new Date(
      startDate.getTime() + Math.random() * 3 * 24 * 60 * 60 * 1000
    ); // 1 to 3 days

    let title;
    if (category === "conference") {
      title = `${getRandomElement(["Annual", "International", "Regional"])} ${
        titles[0]
      }`;
    } else if (category === "music") {
      title = `${getRandomElement(["Summer", "Winter", "Spring", "Autumn"])} ${
        titles[4]
      }`;
    } else {
      title = `${getRandomElement(["Monthly", "Quarterly", "Annual"])} ${
        titles[6]
      }`;
    }

    const event = new Event({
      title,
      description: `This is a ${category} event happening in ${getRandomElement(
        locations
      )}. Join us for an amazing experience!`,
      category,
      start_date: startDate,
      end_date: endDate,
      location: getRandomElement(locations),
      organizer_id: getRandomElement(organizers)._id,
      capacity: Math.floor(Math.random() * 500) + 50,
      price: {
        standard: getRandomPrice(50, 200),
        vip: getRandomPrice(200, 500),
      },
      status: getRandomElement(["draft", "published"]),
    });

    await event.save();
    events.push(event);
  }

  console.log(`Create ${events.length} Activities`);
  return events;
};

// Create ticketing
const createTickets = async (users, events) => {
  const tickets = [];
  const types = ["standard", "vip"];
  const statuses = ["active", "used", "refunded"];

  // Only retrieve users whose role is 'user'
  const regularUsers = users.filter((user) => user.role === "user");

  // Only retrieve the published activities
  const publishedEvents = events.filter(
    (event) => event.status === "published"
  );

  for (let i = 0; i < 50; i++) {
    const user = getRandomElement(regularUsers);
    const event = getRandomElement(publishedEvents);
    const type = getRandomElement(types);
    const price = type === "vip" ? event.price.vip : event.price.standard;

    const ticket = new Ticket({
      event_id: event._id,
      user_id: user._id,
      type,
      price,
      status: getRandomElement(statuses),
      purchased_at: getRandomDate(new Date(2024, 0, 1), new Date()),
    });

    await ticket.save();
    tickets.push(ticket);
  }

  console.log(`Create ${tickets.length} tickets`);
  return tickets;
};

// main function
const seedData = async () => {
  try {
    await clearDatabase();

    const users = await createUsers();
    const organizers = users.filter((user) => user.role === "organizer");
    const events = await createEvents(organizers);
    const tickets = await createTickets(users, events);

    console.log("The test data is complete!");
    mongoose.disconnect();
  } catch (error) {
    console.error("Error:", error);
    process.exit(1);
  }
};

seedData();
