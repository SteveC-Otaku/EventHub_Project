const swaggerJsDoc = require("swagger-jsdoc");

const swaggerOptions = {
  swaggerDefinition: {
    openapi: "3.0.0",
    info: {
      title: "Event System Management API",
      version: "1.0.0",
      description: "Event-System-Management RESTful API document",
      contact: {
        name: "CSIT314 Team",
      },
      servers: [
        {
          url: "http://localhost:5000",
          description: "developing server",
        },
      ],
    },
  },
  apis: ["./src/routes/*.js"], // path of API route
};

const swaggerDocs = swaggerJsDoc(swaggerOptions);

module.exports = swaggerDocs;
