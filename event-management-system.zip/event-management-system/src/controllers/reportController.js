const Event = require("../models/Event");
const Ticket = require("../models/Ticket");
const User = require("../models/User");

// create sales reports
exports.generateSalesReport = async (req, res) => {
  try {
    // check authorization
    if (req.user.role !== "organizer" && req.user.role !== "admin") {
      return res.status(403).json({ message: "no authorization" });
    }

    const { event_id, start_date, end_date } = req.query;
    const filter = {};

    // you can only view your own events if you are organizer
    if (req.user.role === "organizer") {
      filter.organizer_id = req.user._id;
    }

    // If a specific activity is provided, filter
    if (event_id) {
      filter._id = event_id;
    }

    // search event
    const events = await Event.find(filter);
    const eventIds = events.map((event) => event._id);

    // Build ticket inquiry conditions
    const ticketFilter = { event_id: { $in: eventIds } };

    if (start_date && end_date) {
      ticketFilter.purchased_at = {
        $gte: new Date(start_date),
        $lte: new Date(end_date),
      };
    }

    // Check ticket sales
    const tickets = await Ticket.find(ticketFilter).populate(
      "event_id",
      "title"
    );

    // Sales statistics grouped by activity
    const salesByEvent = {};
    let totalSales = 0;

    tickets.forEach((ticket) => {
      const eventId = ticket.event_id._id.toString();
      const eventTitle = ticket.event_id.title;

      if (!salesByEvent[eventId]) {
        salesByEvent[eventId] = {
          title: eventTitle,
          totalSales: 0,
          ticketCount: 0,
          ticketTypes: { standard: 0, vip: 0 },
        };
      }

      salesByEvent[eventId].totalSales += ticket.price;
      salesByEvent[eventId].ticketCount += 1;
      salesByEvent[eventId].ticketTypes[ticket.type] += 1;

      totalSales += ticket.price;
    });

    // generate a report
    const report = {
      type: "sales",
      generatedDate: new Date(),
      params: {
        event_id,
        start_date,
        end_date,
      },
      summary: {
        totalEvents: events.length,
        totalTickets: tickets.length,
        totalSales,
      },
      details: salesByEvent,
    };

    res.json(report);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "server error", error: error.message });
  }
};

// Generate user activity reports
exports.generateUserActivityReport = async (req, res) => {
  try {
    // Only administrators have access
    if (req.user.role !== "admin") {
      return res.status(403).json({ message: "no authorization" });
    }

    const { start_date, end_date } = req.query;

    // Statistics of user registration
    const userFilter = {};
    if (start_date && end_date) {
      userFilter.created_at = {
        $gte: new Date(start_date),
        $lte: new Date(end_date),
      };
    }

    const totalUsers = await User.countDocuments();
    const newUsers = await User.countDocuments(userFilter);

    // Ticket statistics
    const ticketFilter = {};
    if (start_date && end_date) {
      ticketFilter.purchased_at = {
        $gte: new Date(start_date),
        $lte: new Date(end_date),
      };
    }

    const totalTickets = await Ticket.countDocuments();
    const ticketSales = await Ticket.countDocuments(ticketFilter);

    // Count active users (users who have purchased tickets)
    const activeUsers = await Ticket.distinct("user_id", ticketFilter).length;

    // generate a report
    const report = {
      type: "user_activity",
      generatedDate: new Date(),
      params: {
        start_date,
        end_date,
      },
      summary: {
        totalUsers,
        newUsers,
        totalTickets,
        ticketSales,
        activeUsers,
      },
    };

    res.json(report);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "server error", error: error.message });
  }
};
