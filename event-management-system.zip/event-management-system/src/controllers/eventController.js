const Event = require("../models/Event");

// create new activity
exports.createEvent = async (req, res) => {
  try {
    const {
      title,
      description,
      category,
      start_date,
      end_date,
      location,
      capacity,
      price,
    } = req.body;

    const event = await Event.create({
      title,
      description,
      category,
      start_date,
      end_date,
      location,
      organizer_id: req.user._id,
      capacity,
      price,
      status: "draft",
    });

    res.status(201).json(event);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "server error", error: error.message });
  }
};

// gain all activity
exports.getEvents = async (req, res) => {
  try {
    // Support filtering queries
    const { category, location, date, keyword } = req.query;
    const filter = {};

    if (category) filter.category = category;
    if (location) filter.location = { $regex: location, $options: "i" };
    if (keyword) filter.title = { $regex: keyword, $options: "i" };
    if (date) {
      const searchDate = new Date(date);
      filter.start_date = { $lte: searchDate };
      filter.end_date = { $gte: searchDate };
    }

    filter.status = "published"; // Only retrieve the published activities

    const events = await Event.find(filter).populate(
      "organizer_id",
      "name email"
    );
    res.json(events);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "sever error", error: error.message });
  }
};

// Get a single activity
exports.getEvent = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id).populate(
      "organizer_id",
      "name email"
    );

    if (!event) {
      return res.status(404).json({ message: "no activity found" });
    }

    res.json(event);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "server error", error: error.message });
  }
};

// update activity
exports.updateEvent = async (req, res) => {
  try {
    let event = await Event.findById(req.params.id);

    if (!event) {
      return res.status(404).json({ message: "No activity found" });
    }

    // Check if you are the event organizer or administrator.
    if (
      event.organizer_id.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res
        .status(403)
        .json({ message: "You have no right to operate this activity." });
    }

    // update activity
    event = await Event.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    res.json(event);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "server error", error: error.message });
  }
};

// delete activity
exports.deleteEvent = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);

    if (!event) {
      return res.status(404).json({ message: "activity not found" });
    }

    // Check if you are the event organizer or administrator
    if (
      event.organizer_id.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({ message: "no authourization" });
    }

    await event.remove();

    res.json({ message: "activity is deleted" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "server error", error: error.message });
  }
};
