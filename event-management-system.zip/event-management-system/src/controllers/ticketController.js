const Ticket = require("../models/Ticket");
const Event = require("../models/Event");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

// Purchase tickets
exports.purchaseTicket = async (req, res) => {
  try {
    const { event_id, type, paymentMethodId } = req.body;

    // Search Events
    const event = await Event.findById(event_id);
    if (!event) {
      return res.status(404).json({ message: "activity is not found" });
    }

    // Check the activity status
    if (event.status !== "published") {
      return res
        .status(400)
        .json({ message: "Tickets are not available for this event" });
    }

    // calculate tickets price
    const price = type === "vip" ? event.price.vip : event.price.standard;

    // process payment
    const paymentIntent = await stripe.paymentIntents.create({
      amount: price * 100,
      currency: "aud",
      payment_method: paymentMethodId,
      confirm: true,
    });

    if (paymentIntent.status === "succeeded") {
      // Create ticketing
      const ticket = await Ticket.create({
        event_id,
        user_id: req.user._id,
        type,
        price,
        status: "active",
      });

      res.status(201).json({
        success: true,
        ticket,
      });
    } else {
      res.status(400).json({
        success: false,
        message: "payment failed",
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "server error", error: error.message });
  }
};

// Obtain the user's ticket information
exports.getUserTickets = async (req, res) => {
  try {
    const tickets = await Ticket.find({ user_id: req.user._id }).populate({
      path: "event_id",
      select: "title start_date end_date location",
    });

    res.json(tickets);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "server error", error: error.message });
  }
};

// refund
exports.refundTicket = async (req, res) => {
  try {
    const { ticket_id } = req.params;

    const ticket = await Ticket.findById(ticket_id);
    if (!ticket) {
      return res.status(404).json({ message: "The ticket was not found" });
    }

    // Check if the user is the owner or administrator of the ticket
    if (
      ticket.user_id.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res
        .status(403)
        .json({ message: "You have no right to operate this ticket" });
    }

    // Check the ticket status
    if (ticket.status !== "active") {
      return res
        .status(400)
        .json({ message: "Only active tickets can be refunded" });
    }

    // Execute the refund logic
    ticket.status = "refunded";
    await ticket.save();

    res.json({
      success: true,
      message: "Refund successful",
      ticket,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "server error", error: error.message });
  }
};
