const express = require("express");
const router = express.Router();
const {
  purchaseTicket,
  getUserTickets,
  refundTicket,
} = require("../controllers/ticketController");
const { protect } = require("../middleware/authMiddleware");

router.route("/").post(protect, purchaseTicket).get(protect, getUserTickets);

router.route("/:ticket_id/refund").post(protect, refundTicket);

module.exports = router;
