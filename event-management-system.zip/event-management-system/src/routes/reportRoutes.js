const express = require("express");
const router = express.Router();
const {
  generateSalesReport,
  generateUserActivityReport,
} = require("../controllers/reportController");
const { protect, authorize } = require("../middleware/authMiddleware");

router.get(
  "/sales",
  protect,
  authorize("organizer", "admin"),
  generateSalesReport
);
router.get(
  "/user-activity",
  protect,
  authorize("admin"),
  generateUserActivityReport
);

module.exports = router;
