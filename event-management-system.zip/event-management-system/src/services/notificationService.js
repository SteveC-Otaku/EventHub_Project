// simple notification service
const logger = console;

class NotificationService {
  // regular notification
  static async sendNotification(userId, title, message) {
    logger.log(`Notification to ${userId}: ${title} - ${message}`);
    return { success: true, userId, title, message };
  }

  // Send activity reminders
  static async sendEventReminder(userId, eventId, eventTitle, eventDate) {
    const message = `Attention: Activity"${eventTitle}"is going to ${new Date(
      eventDate
    ).toLocaleString()}start`;
    logger.log(`Event Reminder to ${userId}: ${message}`);
    return { success: true, userId, eventId, message };
  }

  // Send ticket confirmation
  static async sendTicketConfirmation(
    userId,
    ticketId,
    eventTitle,
    ticketType
  ) {
    const message = `您已成功购买"${eventTitle}"的${
      ticketType === "vip" ? "VIP" : "标准"
    }票`;
    logger.log(`Ticket Confirmation to ${userId}: ${message}`);
    return { success: true, userId, ticketId, message };
  }

  // Send the refund confirmation
  static async sendRefundConfirmation(userId, ticketId, eventTitle, amount) {
    const message = `Your"${eventTitle}"ticket is refunded, price: ¥${amount}`;
    logger.log(`Refund Confirmation to ${userId}: ${message}`);
    return { success: true, userId, ticketId, message };
  }
}

module.exports = NotificationService;
