const jwt = require("jsonwebtoken");
const User = require("../models/User");

// Protecting route middleware
exports.protect = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    try {
      // gain token
      token = req.headers.authorization.split(" ")[1];

      // authentication token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Obtain user information (excluding password)
      req.user = await User.findById(decoded.id).select("-password");

      next();
    } catch (error) {
      console.error(error);
      return res
        .status(401)
        .json({ message: "Unauthorized, token verification failed" });
    }
  }

  if (!token) {
    return res.status(401).json({ message: "Unauthorized, no token" });
  }
};

// Role authorization middleware
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res
        .status(403)
        .json({ message: `role ${req.user.role} You have no access` });
    }
    next();
  };
};
